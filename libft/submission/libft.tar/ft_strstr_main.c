/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr_main.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: creek <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/01 21:23:23 by creek             #+#    #+#             */
/*   Updated: 2018/12/01 22:32:46 by creek            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

char	*ft_strstr(const char *haystack, const char *needle);

int		main()
{
	char *haystack1 = "abcdehkoiuhguihg";
	char *needle1 = "gg";
	printf("%s\n", strstr(haystack1, needle1));

	char *haystack2 = "abcdehkoiuhguihg";
    char *needle2 = "gg";
    printf("%s\n", ft_strstr(haystack2, needle2));
}
